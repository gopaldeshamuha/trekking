// Shortcuts for selecting elements
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// Set current year in footer
$("#year").textContent = new Date().getFullYear();

// Mobile nav toggle
const navToggle = $(".nav-toggle");
const siteNav = $(".site-nav");

navToggle.addEventListener("click", () => {
  const isOpen = siteNav.style.display === "flex";
  siteNav.style.display = isOpen ? "none" : "flex";
  navToggle.setAttribute("aria-expanded", !isOpen);
});

// Close mobile nav when clicking on links
$$(".site-nav a").forEach(a =>
  a.addEventListener("click", () => {
    if (window.innerWidth < 560) {
      siteNav.style.display = "none";
      navToggle.setAttribute("aria-expanded", "false");
    }
  })
);

// Close mobile nav when clicking outside
document.addEventListener("click", (e) => {
  if (window.innerWidth < 560 && 
      !navToggle.contains(e.target) && 
      !siteNav.contains(e.target) && 
      siteNav.style.display === "flex") {
    siteNav.style.display = "none";
    navToggle.setAttribute("aria-expanded", "false");
  }
});

// Global variables
let treks = [];

// Fetch treks from backend API
async function loadTreks() {
  try {
    const response = await fetch('/api/treks');
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    treks = data;
    renderTreks(treks);
    populateTrekDropdown(treks);
  } catch (err) {
    console.error('Error loading treks:', err);
    $("#trekList").innerHTML = `
      <div class="error-message">
        <p>Failed to load treks. Please try again later.</p>
        <button onclick="loadTreks()" class="btn btn-primary">Retry</button>
      </div>
    `;
  }
}

// Render trek cards
function renderTreks(list) {
  const container = $("#trekList");
  if (!list.length) {
    container.innerHTML = "<p class='loading'>No treks found matching your criteria.</p>";
    return;
  }
  
  container.innerHTML = list.map(t => `
    <article class="trek-card" data-id="${t.id}">
      <div class="trek-media">
        <img src="${t.image || 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800'}" 
             alt="${t.name}" 
             onerror="this.src='https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800'">
      </div>
      <div class="trek-body">
        <h3>${t.name}</h3>
        <p class="trek-description">${t.description ? t.description.substring(0, 120) + '...' : 'Discover this amazing trek experience.'}</p>
        <div class="badges">
          <span class="badge">${t.difficulty}</span>
          <span class="badge">${t.duration} days</span>
          <span class="badge">${t.max_altitude}ft</span>
        </div>
        <div class="trek-footer">
          <button type="button" class="btn btn-primary btn-sm view-details-btn" data-id="${t.id}">
            View Details
          </button>
        </div>
      </div>
    </article>
  `).join("");
}

// Populate trek dropdown in registration form
function populateTrekDropdown(trekList) {
  const select = $("select[name='trek']");
  if (select) {
    select.innerHTML = '<option value="">Select a trek</option>' +
      trekList.map(t => `<option value="${t.id}">${t.name}</option>`).join("");
  }
}

// Filter functionality
$("#trekSearch").addEventListener("input", applyFilters);
$("#difficultyFilter").addEventListener("change", applyFilters);

function applyFilters() {
  const query = $("#trekSearch").value.toLowerCase().trim();
  const difficulty = $("#difficultyFilter").value;
  
  const filtered = treks.filter(t => {
    const matchQuery = !query || 
      t.name.toLowerCase().includes(query) || 
      t.base_village?.toLowerCase().includes(query) ||
      t.description?.toLowerCase().includes(query);
    const matchDifficulty = !difficulty || t.difficulty === difficulty;
    return matchQuery && matchDifficulty;
  });
  
  renderTreks(filtered);
}

// Modal functionality
const trekModal = $("#trekModal");
const modalBody = $("#modalBody");
const closeBtn = $(".close-btn");

// Handle trek details modal
$("#trekList").addEventListener("click", (e) => {
  if (e.target.classList.contains('view-details-btn')) {
    const trekId = e.target.getAttribute('data-id');
    const trek = treks.find(t => t.id == trekId);
    if (!trek) return;
    
    showTrekModal(trek);
  }
});

function showTrekModal(trek) {
  modalBody.innerHTML = `
    <div class="modal-header">
      <h2>${trek.name}</h2>
      <img src="${trek.image || 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800'}" 
           alt="${trek.name}" 
           style="width: 100%; height: 200px; object-fit: cover; border-radius: 12px; margin: 1rem 0;"
           onerror="this.src='https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800'">
    </div>
    
    <div class="trek-details">
      <div class="detail-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin: 1rem 0;">
        <div><strong>Duration:</strong> ${trek.duration} days</div>
        <div><strong>Difficulty:</strong> ${trek.difficulty}</div>
        <div><strong>Trek Length:</strong> ${trek.trek_length} km</div>
        <div><strong>Max Altitude:</strong> ${trek.max_altitude} ft</div>
        <div><strong>Base Village:</strong> ${trek.base_village}</div>
        <div><strong>Transport:</strong> ${trek.transport}</div>
      </div>
      
      <div style="margin: 1rem 0;">
        <strong>Meals:</strong> ${trek.meals}
      </div>
      
      <div style="margin: 1rem 0;">
        <strong>Sightseeing:</strong> ${trek.sightseeing}
      </div>
      
      <div style="margin: 1rem 0;">
        <strong>Description:</strong>
        <p style="margin-top: 0.5rem; line-height: 1.6;">${trek.description}</p>
      </div>
    </div>
    
    <hr style="margin: 2rem 0; border: none; height: 1px; background: rgba(255,255,255,0.1);">
    
    <div class="booking-section">
      <h3>Book This Trek</h3>
      <form id="bookingForm" style="margin-top: 1rem;">
        <div class="form-grid">
          <label>Full Name*
            <input type="text" name="fullName" required>
          </label>
          <label>Contact Number*
            <input type="tel" name="contact" required>
          </label>
          <label class="full">Email*
            <input type="email" name="email" required>
          </label>
        </div>
        <div class="form-actions" style="margin-top: 1rem;">
          <button type="submit" class="btn btn-primary">Submit Booking</button>
          <p class="form-msg" role="status" aria-live="polite"></p>
        </div>
      </form>
    </div>
  `;
  
  trekModal.style.display = "flex";
  
  // Handle booking form submission
  const bookingForm = $("#bookingForm");
  bookingForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    await handleBookingSubmission(trek.id, bookingForm);
  });
}

// Handle booking form submission
async function handleBookingSubmission(trekId, form) {
  const formData = new FormData(form);
  const bookingData = {
    trek_id: trekId,
    fullName: formData.get('fullName'),
    contact: formData.get('contact'),
    email: formData.get('email')
  };
  
  const submitBtn = form.querySelector('button[type="submit"]');
  const messageEl = form.querySelector('.form-msg');
  
  // Show loading state
  submitBtn.disabled = true;
  submitBtn.textContent = 'Submitting...';
  messageEl.textContent = '';
  
  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bookingData)
    });
    
    const result = await response.json();
    
    if (response.ok) {
      messageEl.textContent = 'Booking submitted successfully! We will contact you soon.';
      messageEl.style.color = '#4ade80';
      form.reset();
      
      // Close modal after delay
      setTimeout(() => {
        trekModal.style.display = "none";
      }, 2000);
    } else {
      throw new Error(result.error || 'Booking failed');
    }
  } catch (error) {
    console.error('Booking error:', error);
    messageEl.textContent = 'Failed to submit booking. Please try again.';
    messageEl.style.color = '#ff7aa5';
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Submit Booking';
  }
}

// Close modal functionality
closeBtn.addEventListener("click", () => {
  trekModal.style.display = "none";
});

window.addEventListener("click", (e) => {
  if (e.target === trekModal) {
    trekModal.style.display = "none";
  }
});

// Handle registration form
const registrationForm = $("#registrationForm");
if (registrationForm) {
  registrationForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    
    const formData = new FormData(registrationForm);
    const trekId = formData.get('trek');
    
    if (!trekId) {
      alert('Please select a trek');
      return;
    }
    
    const bookingData = {
      trek_id: trekId,
      fullName: formData.get('name'),
      contact: formData.get('phone'),
      email: formData.get('email')
    };
    
    const submitBtn = registrationForm.querySelector('button[type="submit"]');
    const messageEl = registrationForm.querySelector('.form-msg');
    
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
    messageEl.textContent = '';
    
    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookingData)
      });
      
      const result = await response.json();
      
      if (response.ok) {
        messageEl.textContent = 'Registration submitted successfully! We will contact you soon.';
        messageEl.style.color = '#4ade80';
        registrationForm.reset();
      } else {
        throw new Error(result.error || 'Registration failed');
      }
    } catch (error) {
      console.error('Registration error:', error);
      messageEl.textContent = 'Failed to submit registration. Please try again.';
      messageEl.style.color = '#ff7aa5';
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit Registration';
    }
  });
}

// Handle contact form
const contactForm = $("#contactForm");
if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const messageEl = contactForm.querySelector('.form-msg');
    messageEl.textContent = 'Thank you for your message! We will get back to you soon.';
    messageEl.style.color = '#4ade80';
    contactForm.reset();
  });
}

// Smooth scrolling for navigation links
$$('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Active link highlighting on scroll
const sections = ["home", "about", "treks", "register", "gallery", "contact"]
  .map(id => document.getElementById(id))
  .filter(Boolean);
const navLinks = $$(".site-nav a");

function setActiveLink() {
  const scrollY = window.scrollY + 140;
  let current = sections[0]?.id || 'home';
  
  for (const section of sections) {
    if (section.offsetTop <= scrollY) {
      current = section.id;
    }
  }
  
  navLinks.forEach(link => {
    link.classList.toggle("active", link.getAttribute("href") === `#${current}`);
  });
}

window.addEventListener("scroll", setActiveLink);
window.addEventListener("load", setActiveLink);

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  loadTreks();
  setActiveLink();
});

// Load treks immediately if DOM is already loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadTreks);
} else {
  loadTreks();
}

