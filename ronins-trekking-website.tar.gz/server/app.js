const path = require('path');
const express = require('express');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Create a connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ronins_treks',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// CORS middleware for cross-origin requests
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// GET /api/treks - Fetch all trek data
app.get('/api/treks', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM treks ORDER BY id');
    res.json(rows);
  } catch (err) {
    console.error('Error fetching treks:', err);
    res.status(500).json({ error: 'Error fetching treks' });
  }
});

// GET /api/treks/:id - Fetch single trek by ID
app.get('/api/treks/:id', async (req, res) => {
  const trekId = req.params.id;
  try {
    const [rows] = await pool.query('SELECT * FROM treks WHERE id = ?', [trekId]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Trek not found' });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error('Error fetching trek:', err);
    res.status(500).json({ error: 'Error fetching trek' });
  }
});

// POST /api/bookings - Insert booking information
app.post('/api/bookings', async (req, res) => {
  const { trek_id, fullName, contact, email } = req.body;
  
  // Validate required fields
  if (!trek_id || !fullName || !contact || !email) {
    return res.status(400).json({ 
      error: 'Missing required fields: trek_id, fullName, contact, email' 
    });
  }

  try {
    // Check if trek exists
    const [trekRows] = await pool.query('SELECT id FROM treks WHERE id = ?', [trek_id]);
    if (trekRows.length === 0) {
      return res.status(404).json({ error: 'Trek not found' });
    }

    // Insert booking
    const [result] = await pool.query(
      'INSERT INTO bookings (trek_id, fullName, contact, email, created_at) VALUES (?, ?, ?, ?, NOW())',
      [trek_id, fullName, contact, email]
    );

    res.status(201).json({ 
      message: 'Booking created successfully',
      bookingId: result.insertId 
    });
  } catch (err) {
    console.error('Error creating booking:', err);
    res.status(500).json({ error: 'Error creating booking' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Catch-all handler for frontend routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});

module.exports = app;

